#類別一
class bot:
    def __init__(self,agility,defense,offense):
        self.agility = agility
        self.defense = defense
        self.offense = offense
    
    def print_agility(self):
        print(self.agility)
    
    def print_defense(self):
        print(self.defense)
    
    def print_offense(self):
        print(self.offense)
