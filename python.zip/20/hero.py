#類別二
class hero:
    def __init__(self,agility,defense,offense,HP):
        self.agility = agility
        self.defense = defense
        self.offense = offense
        self.HP = HP

    def agility(self):
        print(self.agility)
    
    def defense(self):
        print(self.defense)
    
    def offense(self):
        print(self.offense)
    
    def HP(self):
        print(self.HP)