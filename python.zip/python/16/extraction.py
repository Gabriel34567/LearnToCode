import random

def extractNum(a,b):
    print(random.randint(a,b))