#Python教學 (初學者入門)
#影片(不是我的！)：https://www.youtube.com/watch?v=zdMUJJKFdsU
#如果要清除終端機的所有指令，用cls(Windows) / clear(Mac) 清除指令

#X. 字典 DICTIONARY
#欸！就是那個字典！
#Python字典：
sampleDic = {"什麼":"What"} #{鍵：值}

#X1. 創建字典
dictionary = {"迷因":"Meme","我的世界":"Minecraft","機械磚塊":"Roblox"}
#":"是一對值之間的連接
#","是分開兩對值的符號

#X2. 查字典囉！
print(dictionary["迷因"]) #中括號內寫的是鍵！

#補充：
newDic = {3.14159:"π",69:"NICE",87:"SB"} #鍵可以是數字哦！
print(newDic[3.14159])