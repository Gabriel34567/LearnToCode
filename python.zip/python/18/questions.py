#你也可以不使用模組，直接在原檔案中自定義函式

class question:
    def __init__(self,desc,correctAnswer):
        self.desc = desc
        self.correctAnswer = correctAnswer